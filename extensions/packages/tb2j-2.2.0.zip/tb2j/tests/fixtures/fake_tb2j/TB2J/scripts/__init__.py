"""Test CLI namespace."""
