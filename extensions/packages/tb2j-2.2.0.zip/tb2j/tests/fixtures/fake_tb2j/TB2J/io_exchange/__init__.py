"""Test reader namespace."""
